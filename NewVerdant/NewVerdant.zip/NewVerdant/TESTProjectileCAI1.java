//Projectile Test
public class TESTProjectileCAI1 extends Projectile{
    public TESTProjectileCAI1( float x, float y, float w, float h ){
        super( x, y, 40, 40, "Images\\Circle.png" );
    }
}
