
/**
 * Write a description of class Magic here.
 * 
 * @author Eric Tria 
 * @version 1.0 Apr 22, 2016
 */
public class Magic extends Projectile
{
    public Magic( float x, float y, float w, float h ){
        super( x, y, w, h, "Images\\sharkfin.png" );
        ProjectileCollisionable pj = new ProjectileCollisionable();
        pj.setDamage(13);
        collisionable = pj;
    }
}
